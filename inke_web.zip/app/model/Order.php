<?php


namespace app\model;


use think\Collection;
use think\Model;

class Order extends Model
{
    protected $table = 'order';
}