<?php


namespace app\model;


use think\Model;

class Change extends Model
{
    protected $table = 'change';
}