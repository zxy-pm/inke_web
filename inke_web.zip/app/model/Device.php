<?php


namespace app\model;


use think\Model;

class Device extends Model
{
    protected $table = 'device';

}