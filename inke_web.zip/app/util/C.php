<?php


namespace app\util;


class C
{
    const salt = 'rppmRECBiYqS7ucI1WO1cGfp0DxH';
    public static $date_fomat = 'Y-m-d H:i:s';
    public static $page_num = 30;
    public static $no_login_actions = ['login','ad_in','t'];
    const key_notice = 'key-notice';
    const key_default_money = 'key-default-money';
}